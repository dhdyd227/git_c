package kr.co.company.singletouch;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;


/*
  저장기능을 하긴했으나... 인터넷 참조하였습니다.
  새로열기 버튼 기능은 비트맵을 배경색으로 채움으로써 초기화
  그리기 버튼 기능은 원래 검은색 팬으로 되돌리는 기능을 작성,지우개 동작시 setStrokeWidth 100f로 증가
  지우개 버튼 기능은 색을 배경색과 같은 거로 등록하여 작성, 또한 팬의 크기를 키워 좀더크게 지울수 있게 만듬(tag의 색을 흰색으로 등록)
 */
public class SingleTouchActivity extends Activity {
	private SingleTouchView drawView;
	private ImageButton currPaint;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);


		drawView = (SingleTouchView) findViewById(R.id.drawing);
		LinearLayout paintLayout = (LinearLayout) findViewById(R.id.paint_colors);
		currPaint = (ImageButton) paintLayout.getChildAt(0);

		ImageButton new_btn= (ImageButton)findViewById(R.id.new_btn); //새로열기
		new_btn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				drawView.clear();
			}
		});

		ImageButton draw_btn=(ImageButton)findViewById(R.id.draw_btn);//그리기
		draw_btn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				String color = view.getTag().toString();
				drawView.setColor(color);
				currPaint = (ImageButton) view;
			}
		});


		ImageButton erase_btn=(ImageButton)findViewById(R.id.erase_btn); //지우개
		erase_btn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View view) {
				String color = view.getTag().toString();
				drawView.setColor(color);
				drawView.erasef(100f);
				currPaint = (ImageButton) view;
			}
		});

		ImageButton save_btn=(ImageButton)findViewById(R.id.save_btn); //저장
		save_btn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				drawView.savePicture();
			}
		});
	}


	public void clicked(View view) {
		if (view != currPaint) {
			String color = view.getTag().toString();
			drawView.setColor(color);
			currPaint = (ImageButton) view;
		}
	}




}
