package kr.co.company.singletouch;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.Environment;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;

public class SingleTouchView extends View {
	private Paint paint = new Paint();
	private Path path = new Path();
	private int paintColor = 0xFF000000;
	private Paint canvasPaint;
	private Canvas drawCanvas;
	private Bitmap canvasBitmap;


	public SingleTouchView(Context context, AttributeSet attrs) {
		super(context, attrs);

		paint.setAntiAlias(true);
		paint.setStrokeWidth(10f);
		paint.setColor(paintColor);
		paint.setStyle(Paint.Style.STROKE);
		paint.setStrokeJoin(Paint.Join.ROUND);
	}


	@Override
	protected void onSizeChanged(int w, int h, int oldw, int oldh) {
		super.onSizeChanged(w, h, oldw, oldh);
		canvasBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
		drawCanvas = new Canvas(canvasBitmap);
		canvasPaint = new Paint(Paint.DITHER_FLAG);

	}

	@Override
	protected void onDraw(Canvas canvas) {
		canvas.drawBitmap(canvasBitmap, 0, 0, canvasPaint);
		canvas.drawPath(path, paint);
	}

	public void clear() {
		canvasBitmap.eraseColor(Color.WHITE);
		invalidate();

	}


	@Override
	public boolean onTouchEvent(MotionEvent event) {
		// detect user touch
		float touchX = event.getX();
		float touchY = event.getY();
		switch (event.getAction()) {
			case MotionEvent.ACTION_DOWN:
				path.moveTo(touchX, touchY);
				break;
			case MotionEvent.ACTION_MOVE:
				path.lineTo(touchX, touchY);
				break;
			case MotionEvent.ACTION_UP:
				drawCanvas.drawPath(path, paint);
				path.reset();
				break;
			default:
				return false;
		}
		invalidate();
		return true;

	}

	protected void erasef(float erasef) {
		invalidate();
		paint.setStrokeWidth(erasef);
	}

	public void setColor(String newColor) {
		invalidate();
		paintColor = Color.parseColor(newColor);
		paint.setColor(paintColor);
		paint.setStrokeWidth(10f);
	}

    public void savePicture() {
        // 1. 캐쉬(Cache)를 허용시킨다.
        // 2. 그림을 Bitmap 으로 저장.
        // 3. 캐쉬를 막는다.

       // mDrawView.setDrawingCacheEnabled(true);    // 캐쉬허용

        // 캐쉬에서 가져온 비트맵을 복사해서 새로운 비트맵(스크린샷) 생성
       // Bitmap screenshot = Bitmap.createBitmap(mDrawView.getDrawingCache());
       // mDrawView.setDrawingCacheEnabled(false);   // 캐쉬닫기
        // SDCard(ExternalStorage) : 외부저장공간
        // 접근하려면 반드시 AndroidManifest.xml에 권한 설정을 한다.

        File dir =
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
        // 폴더가 있는지 확인 후 없으면 새로 만들어준다.

        if(!dir.exists())
            dir.mkdirs();
        FileOutputStream fos;
        try {
            fos = new FileOutputStream(new File(dir, "board.png"));
            canvasBitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
            fos.close();
            Toast.makeText(this.getContext(), "저장 성공", 0).show();
        } catch (Exception e) {

            Log.e("phoro","그림저장오류",e);
            Toast.makeText(this.getContext(), "저장 실패", 0).show();
        }
    }

}