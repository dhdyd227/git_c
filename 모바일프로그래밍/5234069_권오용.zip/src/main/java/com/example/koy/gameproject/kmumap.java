package com.example.koy.gameproject;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.PointF;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;


import com.skt.Tmap.TMapData;
import com.skt.Tmap.TMapMarkerItem;
import com.skt.Tmap.TMapMarkerItem2;
import com.skt.Tmap.TMapOverlayItem;
import com.skt.Tmap.TMapPoint;
import com.skt.Tmap.TMapPolyLine;
import com.skt.Tmap.TMapView;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

//35.855395, 128.483231
public class kmumap extends AppCompatActivity implements SensorEventListener{

    String putPlace;
    Double tLatitude=0d;
    Double Longitude=0d;
    //final ArrayList<Place> alTMapPoint = new ArrayList<Place>();

    TMapView mMapView = null;
    TextView guide;
    TextView score;
    Button direction,cancel,quizebutton,scorecheck,checksee;

    RelativeLayout mapContainer = null;

    LinearLayout bottom;
    LinearLayout listlayout;

    int layoutcheck=0;

    public static Context mContext;  // 타 액티비티에서 변수or함수를 사용가능하게함
    Geocoder coder;
    public static double latitude_plic;
    public static double longitude_plic;

    public static TMapPoint point2;
    public static double Ddistance;
    public static List<NodeData> nodeDatas = new ArrayList<NodeData>();

    DBHelper helper;
    SQLiteDatabase db;

    int gpscheck=0;
    String scorestr;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.kmumap);

        helper = new DBHelper(this);

        try {
            db = helper.getWritableDatabase(); //존재하면 쓰고
        }
        catch (SQLiteException ex) {              // 그렇지 않으면 읽기 권한으로 시작
            db = helper.getReadableDatabase();
        }

        ArrayList<Place> listplace = new ArrayList<Place>();
        listplace = alTMapPoint();

        bottom=(LinearLayout)findViewById(R.id.listlayout);
        listlayout=(LinearLayout)findViewById(R.id.bottom);

        //quize clickAdapter = new quize(this);

        guide=(TextView)findViewById(R.id.guidetext);
        guide.setText("안내".toString());

        mapContainer = (RelativeLayout) findViewById(R.id.kmumap);

        mMapView = new TMapView(this);
        mapContainer.addView(mMapView);
        mMapView.setSKTMapApiKey("27db3851-7386-41aa-9e40-7abfd214cc7e");

        mMapView.setLanguage(TMapView.LANGUAGE_KOREAN);  // 지도 언어 설정
        mMapView.setMapType(TMapView.MAPTYPE_STANDARD);  // 지도 타입 표준


       /* alTMapPoint.add(new TMapPoint(35.856746, 128.489835));//계명대학교 행소박물관
        TMapPoint(35.854448, 128.490685));//계명대학교 태권도센터
        TMapPoint(35.855665, 128.491725));//계명대 동문
        TMapPoint(35.857410, 128.489240));//계명대학교 쉐턱관
        TMapPoint(35.859618, 128.488618));//계명대학교 첨단건설재료실험센터
        TMapPoint(35.855801, 128.488937));//계명대학교 본관
        TMapPoint(35.856468, 128.487176));//계명대학교 동산도서관
        TMapPoint(35.855512, 128.487735));//계명대학교 it교육센터
        TMapPoint(35.856944, 128.486176));//계명대학교 계명한학촌
        TMapPoint(35.855279, 128.485646));//계명대학교 사회관
        TMapPoint(35.854248, 128.486120));//계명대학교 바우어관
        TMapPoint(35.857878, 128.484591));//계명대학교 대장일람집
       TMapPoint(35.855395, 128.483231));//계명대학교 노천강당
*/

        Bitmap pin = BitmapFactory.decodeResource(getResources(), R.drawable.markpin);
        pin=Bitmap.createScaledBitmap(pin, 50, 60, true);

        for(int i=0; i<listplace.size(); i++){
     // TMapMarkerItem 물풍선의 크기를 변경하는 것을 제공하지 않음
            TMapMarkerItem tItem = new TMapMarkerItem();

            TMapMarkerItem markerItem1 = new TMapMarkerItem();     // 마커 아이콘 지정

            markerItem1.setTMapPoint((TMapPoint) listplace.get(i).tmappoint); // 마커의 좌표 지정

            markerItem1.setName("sk"+i);
           // markerItem1.setVisible(markerItem1.VISIBLE);
            markerItem1.setIcon(pin);

            markerItem1.setCanShowCallout(true);//풍선뷰의 사용여부를 설정
           // markerItem1.setAutoCalloutVisible(true);

            markerItem1.setPosition(0.5f, 1.0f);
            markerItem1.setCalloutTitle(listplace.get(i).text1); //말풍선의 제목
            // String msg = tItem.getCalloutTitle();
          //  markerItem1.setCalloutSubTitle(alTMapPoint().get(i).text2); //말풍선의 내용
            // String subMsg = tItem.getCalloutSubTitle();`

            //풍선의 왼쪽이미지
           // Bitmap bitmap1 =alTMapPoint().get(i).image;
           // bitmap1=Bitmap.createScaledBitmap(bitmap1, 250, 250, true);
           // markerItem1.setCalloutLeftImage(bitmap1);
            // Bitmap bitmap2 = BitmapFactory.decodeResource(getResources(),R.drawable.markpin);
            //tItem.setCallourRightButtonImage(bitmap2);//풍선오른쪽이미지

            markerItem1.setAutoCalloutVisible(true);//
            //boolean result = tItem.getCanShowCallout();

            mMapView.addMarkerItem("markerItem"+i, markerItem1);            //지도에 마커 추가

        }

      //  ArrayList<Place> data = new ArrayList<Place>(); //student 객체를 받아 ArrayList 생성
        final UsersAdapter adapter = new UsersAdapter(this, listplace); //내부클래스로 선언하기위해 지정
        ListView list = (ListView) findViewById(R.id.list); //list에 listview를 찾아 빌드
        list.setAdapter(adapter); // list에 adapter 값을 넣음


        list.setOnItemClickListener(new AdapterView.OnItemClickListener() { //list view의 항목클릭시 동작
            // @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) { // 항목의 정보를 받아와서 사용

                //mMapView.removeMarkerItem2("TestID");
                Place all = adapter.getItem(position);

                //지도위에 텍스트 계속띄우기
                TMapMarkerItem2 tMapMarkerItem2 = new TMapMarkerItem2();

                tMapMarkerItem2.setTMapPoint(all.tmappoint); // 마커의 좌표 지정
                Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.markpin);
                tMapMarkerItem2.setIcon(bitmap); // 마커 아이콘 지정

                tMapMarkerItem2.setPosition(0.5f, 1.0f); // 마커의 중심점을 중앙, 하단으로 설정
                tMapMarkerItem2.setID("test"); // 마커의 타이틀 지정

                Bitmap image =all.image;
                image=Bitmap.createScaledBitmap(image, 250, 250, true);
                //mContext = this;
                MarkerOverlay marker = new MarkerOverlay(mContext, all.text1,all.text2,image);
                String strID = "TMapMarkerItem2"+position;

                if(mMapView.getMarkerItem2FromID(strID) !=null)
                {
                    mMapView.removeMarkerItem2(strID);
                    }
                    else
                        {
                            marker.setPosition(0.2f, 3f);
                            // marker.getTMapPoint();
                            marker.setID(strID);
                            marker.setMarkerTouch(true);
                            marker.setTMapPoint(new TMapPoint(all.tmappoint.getLatitude(), all.tmappoint.getLongitude()));

                            mMapView.addMarkerItem2(strID, marker);

                            guide.setText(all.text1.toString());
                        }

            }
        });

        direction=(Button)findViewById(R.id.direction);
        final ArrayList<Place> finalListplace = listplace;
        direction.setOnClickListener(new View.OnClickListener() { //경로안내 버튼
            @Override
            public void onClick(View v) {
                finalListplace.size();
                Thread thread1 = new Thread(new Runnable() {

                    public void run() {
                        try {
                            for(int i=0; i<finalListplace.size(); i++){
                                if(guide.getText().equals(finalListplace.get(i).text1))
                                {
                                    putPlace=finalListplace.get(i).text1.toString();
                                    tLatitude=finalListplace.get(i).tmappoint.getLatitude();
                                    Longitude=finalListplace.get(i).tmappoint.getLongitude();
                                    gpscheck=1;
                                    drawPedestrianPath();
                                    mMapView.setCompassMode(true); //현재 보는 방향 (지도회전)
                                    break;
                                }

                            }
                        } catch (Exception ex) {
                            Log.e("SampleThreadActivity", "Exception in processing message.", ex);
                        }
                    }
                });
                thread1.start();


            }
        });

        cancel=(Button)findViewById(R.id.cancel);//취소버튼
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                guide.setText("안내".toString());
                mMapView.removeTMapPath();
                mMapView.setCompassMode(false); //현재 보는 방향 (지도회전)
                point2=null; //경로 길이 자동으로 업데이트 되지않게 하기 위해
            }
        });

        quizebutton=(Button)findViewById(R.id.quizebutton); //문제풀기버튼
        quizebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if((tLatitude+0.0003)>latitude_plic &&(tLatitude-0.0003)<latitude_plic
                        && (Longitude-0.001)<longitude_plic && (Longitude+0.001)>longitude_plic) {

                    Bundle dataBundle = new Bundle(); //값을 quize로 넘겨주기 위해 생성
                    dataBundle.putString("putPlace", putPlace);

                    Intent intent = new Intent(kmumap.this,quize.class);
                    intent.putExtras(dataBundle);
                    startActivity(intent);

               }
            }
        });


        score=(TextView)findViewById(R.id.score);
        scorecheck=(Button)findViewById(R.id.scorecheck); //점수확인버튼
        scorecheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Cursor cursor2 = db.rawQuery("SELECT * FROM score WHERE _id='1';", null); //SQL검색문 사용, 커서를 생성(리스트 뷰 클릭시이용하기위함)
                startManagingCursor(cursor2); //커서를 실행
                cursor2.moveToFirst();
                scorestr=cursor2.getString(1);

                score.setText(scorestr);
            }
        });



        checksee=(Button) findViewById(R.id.checksee);
        checksee.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(layoutcheck==0) {
                    checksee.setText("보기");
                    listlayout.setVisibility(View.GONE);
                    bottom.setVisibility(View.GONE);
                    layoutcheck=1;
                }
                else{
                    checksee.setText("숨기기");
                    listlayout.setVisibility(View.VISIBLE);
                    bottom.setVisibility(View.VISIBLE);
                    layoutcheck=0;

                }
                }
        });

          mMapView.setIconVisibility(true);    // 현재위치 아이콘을 나타낼 것인지 표시
          mMapView.setCenterPoint(128.486249, 35.856187); //계명대학교 좌표



       //mMapView.setSightVisible(true); //바라보는 방향 출력

        mContext = this;  // 타 액티비티에서 접근 가능하게 함.

        coder = new Geocoder(getApplicationContext(), Locale.KOREA);



        final LocationListener locationListener = new LocationListener() {
            public void onLocationChanged(Location location) {

                    latitude_plic = location.getLatitude();
                    longitude_plic = location.getLongitude();

                    if (point2 != null) {
                        drawPedestrianPath();
                        }


                    mMapView.setCenterPoint(longitude_plic, latitude_plic);
                    mMapView.setLocationPoint(longitude_plic, latitude_plic);

                    mMapView.setSightVisible(true); //바라보는 방향 출력
                    mMapView.setTrackingMode(true); //화면중심을 단말의 현재위치로
                }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {
            }

            @Override
            public void onProviderEnabled(String provider) {
            }

            @Override
            public void onProviderDisabled(String provider) {
            }};

        final LocationManager lm = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_COARSE_LOCATION, android.Manifest.permission.ACCESS_FINE_LOCATION}, 1);
        }

            lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, // 등록할 위치제공자(실내에선 NETWORK_PROVIDER 권장)   GPS_PROVIDER
                    3000, // 통지사이의 최소 시간간격 (miliSecond)
                    10, // 통지사이의 최소 변경거리 (m)
                    locationListener);

    }


    public void onSensorChanged(SensorEvent event) {

    }

    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }



    public void drawPedestrianPath()   // 길찾기 함수
    {
        // final TMapPoint point1 = new TMapPoint(latitude_plic,longitude_plic);
        // point2 = new TMapPoint(des_latitude_plic,des_longitude_plic);

        final TMapPoint point1 = new TMapPoint(latitude_plic , longitude_plic);
        point2 = new TMapPoint(tLatitude, Longitude);

        TMapData tmapdata = new TMapData();
        tmapdata.findPathDataWithType(TMapData.TMapPathType.PEDESTRIAN_PATH, point1, point2, new TMapData.FindPathDataListenerCallback() {
            public void onFindPathData(TMapPolyLine polyLine) {
                polyLine.setLineColor(Color.BLUE);
                polyLine.setLineWidth(10);
                Ddistance = polyLine.getDistance(); //남은 거리
                mMapView.addTMapPath(polyLine);
            }
        });
    }

    private void showToast(String s) {
        Toast.makeText(getApplicationContext(), s, Toast.LENGTH_SHORT).show();
    }
    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        //mSensorManager.unregisterListener(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();


    }

    public static boolean isStringDouble(String s) { //숫자인지
        try {
            Double.parseDouble(s);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    public void onInit(int status){

    }

    public class Place {
        TMapPoint tmappoint;
        String text1;
        String text2;
        Bitmap image;

        public Place(TMapPoint tmappoint,String text1,String text2,Bitmap image) { //Turntype = Point 일떄
            this.tmappoint = tmappoint;
            this.text1=text1;
            this.text2=text2;
            this.image=image;

        }

    }

    public ArrayList<Place> alTMapPoint(){
        ArrayList<Place> alTMapPoint = new ArrayList<Place>();
        //alTMapPoint = new ArrayList<Place>();
        TMapPoint coordinates1 = new TMapPoint(35.855395, 128.483231);//계명대학교 노천강당
        String t1="노천강당",tt1=" 2017학년도 계명대학교  입학식 안내\n" +
                " 〇 일 시: 2017년 2월 28일(화)\n" +
                "   -  식전 행사  13:20 ~ 14:00 (태권도 시범공연 등)\n" +
                "   -  입학식      14:00 ~ \n" +
                " 〇 장 소: 성서캠퍼스 노천강당  ";
        Bitmap bitt1=BitmapFactory.decodeResource(getResources(), R.drawable.nochun);


        TMapPoint coordinates2 = new TMapPoint(35.853039, 128.488625);//계명대학교 대운동장
        String t2="대운동장",tt2=
                "계명대 성서캠퍼스 대운동장에 마련된 인라인 트랙.\n" +
                "사진처럼 운동장 외곽을 따라 아스콘 포장이 잘 되어있다.\n" +
                "서울의 한강이나 탄천처럼 장거리 로드를 할 수 있는 \n" +
                "여건이 대구에는 없다.가끔 무작정 달리고 싶을 때 이용한다.\n";
        Bitmap bitt2=BitmapFactory.decodeResource(getResources(), R.drawable.bigfield);

        TMapPoint coordinates3 = new TMapPoint(35.854474, 128.489848);//계명대학교 체육관
        String t3="체육관",tt3=
                "계명대 성서캠퍼스 체육관에서 2018 캡스톤디자인\n" +
                        " 작품전시회가 열리고 있다. 계명대학교(총장 신일희)\n" +
                        "가 지난 7일 성서캠퍼스 체육관에서 '2018 캡스톤디\n" +
                        "자인 프로젝트' 작품전시회를 열었다. ";
        Bitmap bitt3=BitmapFactory.decodeResource(getResources(), R.drawable.psysicaleducation);

        TMapPoint coordinates4 = new TMapPoint(35.856468, 128.487176);//계명대학교 동산도서관
        String t4= "동산도서관", tt4=
                "2012년 하반기에 시작한 도서관 환경개선\n" +
                "공사는 냉난방기 교체를 기반으로하여  \n" +
                "15개월간의 공사기간을 거쳐 1층 노트북\n" +
                "열람실 신설 2층 정보서비스센터 신설, 3층\n" +
                "전자정보실 확대, 자료실의 주제별 배열에서\n " +
                "청구기호순 배열, 1층부터 6층까지 소그룹 토론\n" +
                "공간을 위한 그룹스터디룸 개설하였고 무엇보다\n" +
                "출입부터 시설을 이용하기 위한 시설통합시스템\n" +
                "클리커를 도입하여 체계적인 도서관 시스템을 구축하였다.\n ";
        Bitmap bitt4=BitmapFactory.decodeResource(getResources(), R.drawable.dongsanlibrary);

        TMapPoint coordinates5 = new TMapPoint(35.867249, 128.559476);//계명대학교 우리집
        String t5="우리집",tt5="우리집 테스트 ";
        Bitmap bitt5=BitmapFactory.decodeResource(getResources(), R.drawable.dongsanlibrary);

        TMapPoint coordinates6 = new TMapPoint(35.859305, 128.486902);//계명대학교 공학관
        String t6="공학관",tt6=
                "우리 공과대학에서는 미래의 발전전략에 따라\n" +
                "학생들이 보다 나은 환경에서 교육을 받을  \n" +
                "수 있도록노력하고 있으며 특히, 교육의 질을 \n" +
                "향상시키기 위한 방법을 다양하게 추진하고 있습니다.\n" +
                "계명대학교 공과대학은 1978년에 신설되었으며 현재 \n" +
                "7개의 건물에 5개 학부, 13개 전공과 3개 학과가 있으며,\n " +
                "교육 시설과 환경은 국내 어느 대학과 비교해도 손색이 \n " +
                        "없을 정도로 잘 갖추어져 있습니다.  ";
        Bitmap bitt6=BitmapFactory.decodeResource(getResources(), R.drawable.gonghack);

        //mMapView.setSightVisible(true); //지도 중앙에 출력
        Bitmap bitmap5 = BitmapFactory.decodeResource(getResources(), R.drawable.markpin);
        bitmap5=Bitmap.createScaledBitmap(bitmap5, 50, 60, true);

        Place place1 = new Place(coordinates1,t1,tt1,bitt1);
        Place place2= new Place(coordinates2,t2,tt2,bitt2);
        Place place3 = new Place(coordinates3,t3,tt3,bitt3);
        Place place4 = new Place(coordinates4,t4,tt4,bitt4);
        Place place5 = new Place(coordinates5,t5,tt5,bitt5);
        Place place6 = new Place(coordinates6,t6,tt6,bitt6);

        alTMapPoint.add(place1);
        alTMapPoint.add(place2);
        alTMapPoint.add(place3);
        alTMapPoint.add(place4);
        alTMapPoint.add(place5);
        alTMapPoint.add(place6);


        return alTMapPoint;
    }

    public class UsersAdapter extends ArrayAdapter<Place> { //내부클래스 생성
        public UsersAdapter(Context context, ArrayList<Place> users) {
            super(context, 0, users);
        }
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            // 위치에대한 데이터를 가져옴 position이 0이면 첫번째
            Place place = getItem(position);

            // 기존 뷰가 재사용 되는지 확인
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_user, parent, false);
            }
            TextView title = (TextView) convertView.findViewById(R.id.title);
          //  TextView subtitle = (TextView) convertView.findViewById(R.id.subtitle);

            // 화면에 세팅
            title.setText(place.text1);
           // subtitle.setText(place.text2);
            // Return the completed view to render on screen
            return convertView;
        }
    }


}
