package com.example.koy.gameproject;

import android.content.Context;
import android.graphics.Bitmap;
import android.media.Image;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

class BalloonOverlayView extends FrameLayout {

    private LinearLayout layout;
    private TextView title;
    private TextView subTitle;
    private ImageView image;
    public BalloonOverlayView(Context context, String labelName, String id,Bitmap image) {

        super(context);

        setPadding(10, 0, 10, 0);
        layout = new LinearLayout(context);
        layout.setVisibility(VISIBLE);

        setupView(context, layout, labelName, id, image);

        LayoutParams params = new LayoutParams(
                LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
        params.gravity = Gravity.NO_GRAVITY;
        addView(layout, params);
    }


    protected void setupView(Context context, final ViewGroup parent, String labelName, String id,Bitmap image1) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);


        View view = inflater.inflate(R.layout.balloon_overlay, parent, true);

        title = (TextView) view.findViewById(R.id.balloon_item_title);
        subTitle = (TextView) view.findViewById(R.id.balloon_item_snippet);
        image =(ImageView)view.findViewById(R.id.placeimage);

        setTitle(labelName);
        setSubTitle(id);
        setImage(image1);

    }

    public void setTitle(String str) {
        title.setText(str);
    }

    public void setImage(Bitmap str) {
        image.setImageBitmap(str);
    }

    public void setSubTitle(String str) {
        subTitle.setText(str);
    }
}
