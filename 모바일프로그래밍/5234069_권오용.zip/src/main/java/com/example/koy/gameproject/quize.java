package com.example.koy.gameproject;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

class DBHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "mycontacts.db";  //"mycontacts.db";
    private static final int DATABASE_VERSION = 7; //열의 개수

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    //테이블 이름 contacts
    public void onCreate(SQLiteDatabase db) {  //select 3,4,5
        db.execSQL("CREATE TABLE contacts (_id INTEGER PRIMARY KEY" +
                " AUTOINCREMENT,place TEXT,question TEXT,select1 TEXT, select2 TEXT, select3 TEXT,correct TEXT,checkd TEXT);");  //테이블생성

        db.execSQL("INSERT INTO contacts VALUES (null,'노천강당','현재 도착한 강당의 이름은?','노청강당','도청강당','노천강당','3','0');");//테이블에 데이터 삽입
        db.execSQL("INSERT INTO contacts VALUES (null,'대운동장','계명대학교에서 지금 도착한 운동장의 크기는 몇번쨰로 큰가?','1','2','3','1','0');");//테이블에 데이터 삽입
        db.execSQL("INSERT INTO contacts VALUES (null,'체육관','옆은 무슨 단대의 건물인가?','공대','사회대','체대','3','0');");//테이블에 데이터 삽입
        db.execSQL("INSERT INTO contacts VALUES (null,'동산도서관','동산도서관에 들어가기 위해 필요한것은?','신분증','현금','학생증','3','0');");//테이블에 데이터 삽입
        db.execSQL("INSERT INTO contacts VALUES (null,'우리집','우리집~?','오답','오답','정답','3','0');");//테이블에 데이터 삽입
        db.execSQL("INSERT INTO contacts VALUES (null,'공학관','공과대학은 몇개의 과가 존재하는가? ','18','19','20','1','0');");//테이블에 데이터 삽입


        db.execSQL("CREATE TABLE score (_id INTEGER PRIMARY KEY" +
                " AUTOINCREMENT,score TEXT);");  //테이블생성
        db.execSQL("INSERT INTO score VALUES (null,'0');");//테이블에 데이터 삽입


    }

    //AUTOINCREMENT
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {  //테이블 갱신
        db.execSQL("DROP TABLE IF EXISTS contacts");
        db.execSQL("DROP TABLE IF EXISTS score");
        onCreate(db);
    }
}

public class quize extends AppCompatActivity  {

    /*Context mContext;
    public quize(Context context){
        mContext = context;
    }*/


    SQLiteDatabase db;

    RadioButton select1,select2,select3;
    TextView question;
    Button clear,dbclear;
    String corretcheck="0";

    TextView score;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.quize);

        final DBHelper helper;

        helper = new DBHelper(this);

        try {
            db = helper.getWritableDatabase(); //존재하면 쓰고
        } catch (SQLiteException ex) {              // 그렇지 않으면 읽기 권한으로 시작
            db = helper.getReadableDatabase();
        }


       // LayoutInflater inflater = (LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);
       // View view = inflater.inflate(R.layout.kmumap, null);


        String kmumapplace;
        Intent kmumap = getIntent();
        kmumapplace=kmumap.getStringExtra("putPlace");



        final Cursor cursor = db.rawQuery("SELECT * FROM contacts WHERE place='" + kmumapplace + "';", null); //SQL검색문 사용, 커서를 생성(리스트 뷰 클릭시이용하기위함)
        startManagingCursor(cursor); //커서를 실행

        cursor.moveToFirst();
        if (cursor.getCount() < 1) {

        }
        else{
            select1=(RadioButton)findViewById(R.id.select1);
            select2=(RadioButton)findViewById(R.id.select2);
            select3=(RadioButton)findViewById(R.id.select3);
            question=(TextView)findViewById(R.id.question);

            question.setText(cursor.getString(2));
            select1.setText("1. "+cursor.getString(3));
            select2.setText("2. "+cursor.getString(4));
            select3.setText("3. "+cursor.getString(5));
        }

        final Cursor cursor2 = db.rawQuery("SELECT * FROM score WHERE _id='1';", null); //SQL검색문 사용, 커서를 생성(리스트 뷰 클릭시이용하기위함)
        startManagingCursor(cursor2); //커서를 실행
        cursor2.moveToFirst();

        clear=(Button)findViewById(R.id.clear);
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(corretcheck.equals(cursor.getString(6))){

                    String b= "1";


                    if(b.equals(cursor.getString(7)))
                    {
                        Toast.makeText(getApplicationContext(), "정답입니다.(중복문제로 점수가 오르지 않습니다)", Toast.LENGTH_SHORT).show();
                        finish();

                    }
                    else {
                        Toast.makeText(getApplicationContext(), "정답입니다.", Toast.LENGTH_SHORT).show();
                        ContentValues values = new ContentValues();
                        int a = Integer.parseInt(cursor2.getString(1)) + 20;
                        values.put("score", String.valueOf(a));
                        db.update("score", values, "_id=?", new String[]{"1"});

                        ContentValues values2 = new ContentValues();
                        values2.put("checkd", b);
                        db.update("contacts", values2, "place=?", new String[]{cursor.getString(1)});
                        finish();
                    }

                }
                else {
                    Toast.makeText(getApplicationContext(), "틀렸습니다.", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        });

        RadioGroup Group = (RadioGroup)findViewById(R.id.Group);
        Group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() { //라이오버튼클릭시
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if(R.id.select1 == checkedId) {
                    corretcheck = "1";
                }
                else if(R.id.select2 == checkedId){
                    corretcheck="2";
                }
                else{
                    corretcheck="3";
                }
            }
        });

        dbclear=(Button)findViewById(R.id.dbclear);
        dbclear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                helper.onUpgrade(db,7,7);

            }
        });



    }
}
