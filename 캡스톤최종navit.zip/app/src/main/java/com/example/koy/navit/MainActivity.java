package com.example.koy.navit;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.Locale;

import static android.media.audiofx.AudioEffect.ERROR;


class DBHelper extends SQLiteOpenHelper {
        private static final String DATABASE_NAME = "mycontacts.db";  //"mycontacts.db";
        private static final int DATABASE_VERSION = 5; //열의 개수

        public DBHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        //테이블 이름 contacts
        public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE contacts (_id INTEGER PRIMARY KEY" +
                    " AUTOINCREMENT,idnumber TEXT,address TEXT, tLatitude TEXT, Longitude TEXT);");  //테이블생성
        }
        //AUTOINCREMENT
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {  //테이블 갱신
            db.execSQL("DROP TABLE IF EXISTS contacts");
            onCreate(db);
        }
}

public class MainActivity extends AppCompatActivity {

    String Address;
    Double tLatitude;
    Double Longitude;
    int subcheck = 0;
    String text1,text2,text3,text4;
    DBHelper helper;
    SQLiteDatabase db;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        helper = new DBHelper(this);

        try {
            db = helper.getWritableDatabase(); //존재하면 쓰고
        } catch (SQLiteException ex) {              // 그렇지 않으면 읽기 권한으로 시작
            db = helper.getReadableDatabase();
        }

        Intent submit = getIntent();
        Address = submit.getStringExtra("Address");
        tLatitude = submit.getDoubleExtra("tLatitude", 0);
        Longitude = submit.getDoubleExtra("Longitude", 0);
        subcheck = submit.getIntExtra("subcheck", 0);

        Button tutorial = (Button)findViewById(R.id.tutorial);
        tutorial.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(MainActivity.this, tutorial.class);
                startActivity(intent);
            }
        });

        //"첫번째" 버튼 클릭
        final Button button1 = (Button) findViewById(R.id.button1);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                db = helper.getWritableDatabase();
                Cursor one =db.rawQuery("SELECT * FROM contacts WHERE idnumber='1';", null); //SQL검색문 사용, 커서를 생성(리스트 뷰 클릭시이용하기위함)
                one.moveToPosition(0); //커서가 클릭한 순번을 찾아감(검색 이용)

                if(one.getCount()>0) {

                    Bundle YesNodata = new Bundle();
                    YesNodata.putDouble("tLatitude", Double.parseDouble(one.getString(3)));
                    YesNodata.putDouble("Longitude", Double.parseDouble(one.getString(4)));
                    YesNodata.putString("text", text1);

                    Intent intent = new Intent(MainActivity.this, YesNo.class);
                    intent.putExtras(YesNodata); //데이터를 넘겨줌
                    startActivity(intent);
                    finish();
                }
            }
        });

        button1.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {

                Bundle dataBundle = new Bundle();
                dataBundle.putString("buttonnumber", "1");
                Intent intent = new Intent(MainActivity.this, submit.class);
                intent.putExtras(dataBundle); //데이터를 넘겨줌
                startActivity(intent);
                finish();
                return true;
            }
        });

        //"두번째" 버튼 클릭
        final Button button2 = (Button) findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                db = helper.getWritableDatabase();
                Cursor two =db.rawQuery("SELECT * FROM contacts WHERE idnumber='2';", null); //SQL검색문 사용, 커서를 생성(리스트 뷰 클릭시이용하기위함)
                two.moveToPosition(0); //커서가 클릭한 순번을 찾아감(검색 이용)

                if(two.getCount()>0) {
                    Bundle YesNodata = new Bundle();
                    YesNodata.putDouble("tLatitude", Double.parseDouble(two.getString(3)));
                    YesNodata.putDouble("Longitude", Double.parseDouble(two.getString(4)));
                    YesNodata.putString("text", text2);
                    Intent intent = new Intent(MainActivity.this, YesNo.class);
                    intent.putExtras(YesNodata); //데이터를 넘겨줌
                    startActivity(intent);
                    finish();
                }
            }
        });

        button2.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Bundle dataBundle = new Bundle();
                dataBundle.putString("buttonnumber", "2");
                Intent intent = new Intent(MainActivity.this, submit.class);
                intent.putExtras(dataBundle); //데이터를 넘겨줌
                startActivity(intent);
                finish();
                return true;
            }
        });

        //"세번째" 버튼 클릭
        final Button button3 = (Button) findViewById(R.id.button3);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                db = helper.getWritableDatabase();
                Cursor three =db.rawQuery("SELECT * FROM contacts WHERE idnumber='3';", null); //SQL검색문 사용, 커서를 생성(리스트 뷰 클릭시이용하기위함)
                three.moveToPosition(0); //커서가 클릭한 순번을 찾아감(검색 이용)

                if(three.getCount()>0) {
                    Bundle YesNodata = new Bundle();
                    YesNodata.putDouble("tLatitude", Double.parseDouble(three.getString(3)));
                    YesNodata.putDouble("Longitude", Double.parseDouble(three.getString(4)));
                    YesNodata.putString("text",text3);
                    Intent intent = new Intent(MainActivity.this, YesNo.class);
                    intent.putExtras(YesNodata); //데이터를 넘겨줌
                    startActivity(intent);
                    finish();

                }
            }
        });

        button3.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {

                Bundle dataBundle = new Bundle();
                dataBundle.putString("buttonnumber", "3");
                Intent intent = new Intent(MainActivity.this, submit.class);
                intent.putExtras(dataBundle); //데이터를 넘겨줌
                startActivity(intent);
                finish();
                return true;
            }
        });

        //"네번째" 버튼 클릭
        final Button button4 = (Button) findViewById(R.id.button4);
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                db = helper.getWritableDatabase();
                Cursor five =db.rawQuery("SELECT * FROM contacts WHERE idnumber='4';", null); //SQL검색문 사용, 커서를 생성(리스트 뷰 클릭시이용하기위함)
                five.moveToPosition(0); //커서가 클릭한 순번을 찾아감(검색 이용)

                if(five.getCount()>0) {
                    Bundle YesNodata = new Bundle();
                        YesNodata.putDouble("tLatitude", Double.parseDouble(five.getString(3)));
                        YesNodata.putDouble("Longitude", Double.parseDouble(five.getString(4)));
                        YesNodata.putString("text", text4);
                        Intent intent = new Intent(MainActivity.this, YesNo.class);
                        intent.putExtras(YesNodata); //데이터를 넘겨줌
                        startActivity(intent);
                        finish();
                }
            }
        });

        button4.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {

                Bundle dataBundle = new Bundle();
                dataBundle.putString("buttonnumber", "4");
                Intent intent = new Intent(MainActivity.this, submit.class);
                intent.putExtras(dataBundle); //데이터를 넘겨줌
                startActivity(intent);
                finish();
                return true;
            }
        });


        //초기화
        Button delete = (Button) findViewById(R.id.delete);
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                helper.onUpgrade(db, 5, 5); //DBHelper 에 생성해둔  onUpgrade 호출
            }
        });

        db = helper.getWritableDatabase();

        final Cursor cursor = db.rawQuery("SELECT * FROM contacts", null); //전체 보기

        startManagingCursor(cursor);

        if(cursor.getCount() >0) {
            cursor.moveToFirst();
            button1.setText(cursor.getString(2).toString());
            text1 =cursor.getString(2).toString();
        }
        if(cursor.getCount() >1) {
            cursor.moveToNext();
            button2.setText(cursor.getString(2).toString());
            text2 =cursor.getString(2).toString();

        }
        if(cursor.getCount() >2) {
            cursor.moveToNext();
            button3.setText(cursor.getString(2).toString());
            text3 =cursor.getString(2).toString();

        }
        if(cursor.getCount() >3) {
            cursor.moveToNext();
            button4.setText(cursor.getString(2).toString());
            text4 =cursor.getString(2).toString();

        }
        cursor.close();

    }


    //  Button all = (Button)findViewById(R.id.all);

/*
    public void all(View target) {  //전체보기 SQL문만 수정
        db = helper.getWritableDatabase();

        final Cursor cursor = db.rawQuery("SELECT * FROM contacts", null); //전체 보기

        startManagingCursor(cursor);
        TextView text = (TextView)findViewById(R.id.testtext);
        String a = cursor.getColumnName(0);
        String b = cursor.getColumnName(1);
        String c = cursor.getColumnName(2);
        String d = cursor.getColumnName(3);

        text.setText(a+"   "+b+"   "+"   "+c+"   "+d);
        String[] from = {"idnumber","address","tLatitude","Longitude"};
        int[] to = { R.id.idnumber,R.id.address, R.id.tLatitude, R.id.Longitude};
        final SimpleCursorAdapter adapter = new SimpleCursorAdapter(this, R.layout.item_user, cursor, from, to);

        //item_user   idnumber ,address , tLatitude,Longitude

        ListView list = (ListView)findViewById(R.id.listview);
        list.setAdapter(adapter);
        db.close();
    }
    */

}
