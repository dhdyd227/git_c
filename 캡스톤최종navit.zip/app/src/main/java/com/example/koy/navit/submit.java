package com.example.koy.navit;

import android.Manifest;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PointF;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.skt.Tmap.TMapData;
import com.skt.Tmap.TMapGpsManager;
import com.skt.Tmap.TMapMarkerItem;
import com.skt.Tmap.TMapPoint;
import com.skt.Tmap.TMapView;

import java.util.ArrayList;


public class submit extends AppCompatActivity implements TMapGpsManager.onLocationChangedCallback{

    Double tLatitude;
    Double Longitude;
    String Address;

    String idnumber,StLatitude,SLongitude;

    DBHelper helper;
    SQLiteDatabase db;

    int check;
    public static double latitude_plic;
    public static double longitude_plic;

    private boolean m_bTrackingMode = true;

    private TMapGpsManager tmapgps = null;
    private TMapView tMapView = null;
    private static int mMarkerID;

    private ArrayList<TMapPoint> m_tmapPoint = new ArrayList<TMapPoint>();
    private ArrayList<String> mArrayMarkerID = new ArrayList<String>();

    @Override
    public void onLocationChange(Location location) {
        if (m_bTrackingMode) {
            tMapView.setLocationPoint(location.getLongitude(), location.getLatitude());
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.submit);

        helper = new DBHelper(this);

        try {
            db = helper.getWritableDatabase(); //존재하면 쓰고
        }
        catch (SQLiteException ex) {              // 그렇지 않으면 읽기 권한으로 시작
            db = helper.getReadableDatabase();
        }

        LinearLayout mapView=new LinearLayout(this);
        mapView=(LinearLayout)findViewById(R.id.tmap);

       // final TMapView tMapView = new TMapView(this);
        tMapView = new TMapView(this);
        tMapView.setSKTMapApiKey("27db3851-7386-41aa-9e40-7abfd214cc7e");
        //진영키 : 7463322c-a339-4d2f-9fc1-c66823eb0dc9
        //태용키 : a5ed3227-93b8-49b7-a56d-862ede911d9a
        //오용키: 27db3851-7386-41aa-9e40-7abfd214cc7e
        tMapView.setMapType(TMapView.MAPTYPE_STANDARD);
        tMapView.setLanguage(TMapView.LANGUAGE_KOREAN);//언어
       // tMapView.setTrackingMode(true);
        tMapView.setIconVisibility(true);
        tMapView.setSightVisible(true);
        mapView.addView(tMapView); //맵추가
        //setContentView(mapView);

        Intent buttonnumber = getIntent();
        check = Integer.parseInt(buttonnumber.getStringExtra("buttonnumber"));

        tmapgps = new TMapGpsManager(submit.this);
        tmapgps.setMinTime(1000);
        tmapgps.setMinDistance(5);
        tmapgps.setProvider(tmapgps.NETWORK_PROVIDER);
       // tmapgps.setProvider(tmapgps.GPS_PROVIDER);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(new String[] {Manifest.permission.ACCESS_FINE_LOCATION}, 1); //위치권한 탐색 허용 관련 내용
        }
        tmapgps.OpenGps();


        /*  화면중심을 단말의 현재위치로 이동 */
        tMapView.setTrackingMode(true);
        tMapView.setSightVisible(true);


        // 클릭 이벤트 설정
        tMapView.setOnClickListenerCallBack(new TMapView.OnClickListenerCallback() {
            @Override
            public boolean onPressEvent(ArrayList arrayList, ArrayList arrayList1, TMapPoint tMapPoint, PointF pointF) {
                // Toast.makeText(submit.this, "onPress~!", Toast.LENGTH_SHORT).show();
                tLatitude=tMapPoint.getLatitude();
                Longitude=tMapPoint.getLongitude();

                TMapData tmapdata = new TMapData();

                tmapdata.convertGpsToAddress(tLatitude, Longitude, new TMapData.ConvertGPSToAddressListenerCallback() {
                    @Override
                    public void onConvertToGPSToAddress(String strAddress) {
                        Address=strAddress;
                    }
                });

                return false;
            } //누르고 있을 때 발생

            @Override
            public boolean onPressUpEvent(ArrayList arrayList, ArrayList arrayList1, TMapPoint tMapPoint, PointF pointF) {
                // Toast.makeText(submit.this, "onPressUp~!", Toast.LENGTH_SHORT).show();
                return false;
            } //누르는 걸 때면 발생
        });

        // 롱 클릭 이벤트 설정
        tMapView.setOnLongClickListenerCallback(new TMapView.OnLongClickListenerCallback() {
            @Override
            public void onLongPressEvent(ArrayList arrayList, ArrayList arrayList1, TMapPoint tMapPoint) {

                TMapMarkerItem markerItem1 = new TMapMarkerItem();
// 마커 아이콘
                Bitmap bitmap = BitmapFactory.decodeResource(tMapView.getResources(), R.drawable.pin_r_m_a);

                bitmap=Bitmap.createScaledBitmap(bitmap, 90, 100, true);

                EditText addresstext =(EditText)findViewById(R.id.addresstext);
                addresstext.setText(Address);

                EditText gpstext=(EditText)findViewById(R.id.gpstext);
                gpstext.setText("위도: "+tLatitude.toString() +"\n경도: "+Longitude.toString());

                Toast.makeText(submit.this, "위도: "+tLatitude.toString() +"\n경도: "+Longitude.toString()+"\n주소: "+Address, Toast.LENGTH_SHORT).show();

                TMapPoint tMapPoint1 = new TMapPoint(tLatitude, Longitude);
                markerItem1.setIcon(bitmap); // 마커 아이콘 지정
                markerItem1.setPosition(0.5f, 1.0f); // 마커의 중심점을 중앙, 하단으로 설정
                markerItem1.setTMapPoint( tMapPoint1 ); // 마커의 좌표 지정
                markerItem1.setName("SKT타워"); // 마커의 타이틀 지정
                tMapView.addMarkerItem("markerItem1", markerItem1); // 지도에 마커 추가

                //   Toast.makeText(submit.this, "onLongPress~!", Toast.LENGTH_SHORT).show();
            }//계속 누르고 있을 때 발생
        });


        Button save = (Button)findViewById(R.id.save);
        //"save" 버튼 클릭
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                idnumber = Integer.toString(check);
                StLatitude = Double.toString(tLatitude);
                SLongitude = Double.toString(Longitude);
                EditText addresstext =(EditText)findViewById(R.id.addresstext);

                final Cursor cursor = db.rawQuery("SELECT * FROM contacts WHERE idnumber='" + idnumber + "';", null); //SQL검색문 사용, 커서를 생성(리스트 뷰 클릭시이용하기위함)
                startManagingCursor(cursor); //커서를 실행

                if (cursor.getCount() < 1) {
                    //db = helper.getWritableDatabase();
                    db.execSQL("INSERT INTO contacts VALUES ('"+idnumber+"','"+ idnumber +"','" + addresstext.getText().toString() + "','" + StLatitude + "','"+SLongitude+"');");//테이블에 데이터 삽입

                } else  //idnumber TEXT,address TEXT, tLatitude TEXT, Longitude TEXT
                {
                   // db = helper.getWritableDatabase();
                    ContentValues values = new ContentValues();
                    values.put("address", addresstext.getText().toString());
                    values.put("tLatitude", StLatitude);
                    values.put("Longitude", SLongitude);
                    db.update("contacts", values, "idnumber=?", new String[]{idnumber});
                    //db.execSQL("UPDATE mycontacts.db SET address='"+Address+"' WHERE idnumber="+idnumber+";");
                }
                Bundle dataBundle = new Bundle(); //값을 searchdetail로 넘겨주기 위해 생성
                dataBundle.putInt("subcheck", check);
                dataBundle.putDouble("tLatitude", tLatitude);
                dataBundle.putDouble("Longitude", Longitude);
                dataBundle.putString("Address", Address);

                Intent intent = new Intent(submit.this, MainActivity.class);
                intent.putExtras(dataBundle);

                // Intent s = new Intent(submit.this,MainActivity.class); //인텐트를 생성
                startActivity(intent);  //인텐트 시작(다른 액티비티 접속)

                if (check == 1) {
                    Toast.makeText(submit.this, "1저장되었습니다.", Toast.LENGTH_SHORT).show();
                    finish();
                } else if (check == 2){
                    Toast.makeText(submit.this, "2저장되었습니다.", Toast.LENGTH_SHORT).show();
                    finish();
                }
                else if(check == 3) {
                    Toast.makeText(submit.this, "3저장되었습니다.", Toast.LENGTH_SHORT).show();
                    finish();
                }
                else if(check == 4){
                    Toast.makeText(submit.this,"4저장되었습니다.", Toast.LENGTH_SHORT).show();
                    finish();
                }
                else
                    Toast.makeText(submit.this,"고장.", Toast.LENGTH_SHORT).show();

            }
        });

        Button cancel = (Button)findViewById(R.id.cancel);
        //"cancel" 버튼 클릭
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent s = new Intent(submit.this,MainActivity.class); //인텐트를 생성
                startActivity(s);
                finish();
            }
        });

    }

}