package com.example.koy.navit;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;

import java.util.Locale;
import static android.media.audiofx.AudioEffect.ERROR;


/**
 * Created by koy on 2018-05-16.
 */

public class YesNo extends AppCompatActivity implements TextToSpeech.OnInitListener {

    String Address;
    String ttsCancel="취소되었습니다.";
    String ttsStart="목적지를 안내합니다.";
    Double tLatitude;
    Double Longitude;
    String text;
    private TextToSpeech tts;

    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.yesno);

        Intent submit = getIntent();
        Address=submit.getStringExtra("Address");
        tLatitude=submit.getDoubleExtra("tLatitude",0);
        Longitude=submit.getDoubleExtra("Longitude",0);
        text=submit.getStringExtra("text");
        Button Yes = (Button)findViewById(R.id.Yes);

        tts = new TextToSpeech(this, this);


        //"Yes" 버튼 클릭
        Yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tts.speak(ttsStart.toString(),TextToSpeech.QUEUE_ADD,null);

                Handler mHandler = new Handler();
                mHandler.postDelayed(new Runnable()  {
                    public void run() {
                        Bundle guide = new Bundle();
                        guide.putDouble("tLatitude",tLatitude);
                        guide.putDouble("Longitude",Longitude);
                        Intent intent = new Intent(YesNo.this,guide.class);
                        intent.putExtras(guide); //데이터를 넘겨줌
                        tts.stop();
                        startActivity(intent);
                    }
                }, 2000);


            }
        });

        Button No = (Button)findViewById(R.id.No);
        //"No" 버튼 클릭
        No.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tts.speak(ttsCancel.toString(),TextToSpeech.QUEUE_ADD,null);

                Handler mHandler = new Handler();
                mHandler.postDelayed(new Runnable()  {
                    public void run() {
                        Intent intent = new Intent(YesNo.this,MainActivity.class);
                        startActivity(intent);
                        finish();
                    }
                }, 1000);
            }
        });
    }

    public void onInit(int status) {
        tts.speak(text + ",,, 경로안내는 위, 취소는 아래를 클릭해주세요", TextToSpeech.QUEUE_FLUSH, null);
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        tts.shutdown();

    }

    @Override
    public void onBackPressed(){
        super.onBackPressed();
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);//startActivity(intent);
    }

}

