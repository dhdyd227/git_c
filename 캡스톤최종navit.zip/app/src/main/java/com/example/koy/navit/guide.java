package com.example.koy.navit;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.PointF;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.Handler;
import android.speech.tts.TextToSpeech;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;

import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.skt.Tmap.DraggingAnimateThread;
import com.skt.Tmap.ResourceManager;
import com.skt.Tmap.TMapData;
import com.skt.Tmap.TMapPoint;
import com.skt.Tmap.TMapPolyLine;
import com.skt.Tmap.TMapView;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

import static android.media.AudioManager.ERROR;
import static com.example.koy.navit.CameraOverlayview.nodelan;

/**
 * Created by koy on 2018-05-19.
 */

public class guide extends AppCompatActivity implements SensorEventListener{
    //나침반시작
    private boolean CompassModeguide = false;
    private int currentScreenOrientationguide = 0;

    private SensorManager mSensorManager;
    private Sensor mAccelerometer;
    private Sensor mMagneticField;
    private double mAzimut,mPitch,mRoll;

    private TextView mResultView;

    float[] mGravity;
    float[] mGeomagnetic;
    //나침반 끝

    String Address;
    Double tLatitude;
    Double Longitude;
    int subcheck=0;

    String TAG = "PAAR";
    String Distance;
    TMapView mMapView = null;

    RelativeLayout mapContainer = null;
    public static Context mContext;  // 타 액티비티에서 변수or함수를 사용가능하게함
    Geocoder coder;
    CameraOverlayview mOverlayview;
    CameraActivity mCameraActivity;
    public static double latitude_plic;
    public static double longitude_plic;

    public static TMapPoint point2;
    public static double Ddistance;

    private TextToSpeech tts;
    Button direction;
    int check2=1;
    int start;
    String thread;
    public static List<NodeData> nodeDatas = new ArrayList<NodeData>();

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guide);

        //나침시작
        mResultView = (TextView) findViewById(R.id.texttest);

        mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        mAccelerometer = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        mMagneticField = mSensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);

        mSensorManager.registerListener(this, mAccelerometer, SensorManager.SENSOR_DELAY_NORMAL);
        mSensorManager.registerListener(this, mMagneticField, SensorManager.SENSOR_DELAY_NORMAL);
        //나침종료

        Intent submit = getIntent();
        Address=submit.getStringExtra("Address"); //주소이름
        tLatitude=submit.getDoubleExtra("tLatitude",0); //목적지 위도
        Longitude=submit.getDoubleExtra("Longitude",0); //목적지 경도

/*
        tLatitude=35.867234 ;
        Longitude=128.559484;
        latitude_plic=35.871640;
        longitude_plic=128.559421;
*/
        mapContainer = (RelativeLayout) findViewById(R.id.guide);

        mMapView = new TMapView(this);
        mapContainer.addView(mMapView);
        mMapView.setSKTMapApiKey("27db3851-7386-41aa-9e40-7abfd214cc7e");
        //진영키: 7463322c-a339-4d2f-9fc1-c66823eb0dc9
        //태용키 : a5ed3227-93b8-49b7-a56d-862ede911d9a
        //ㅇ오용키: 27db3851-7386-41aa-9e40-7abfd214cc7e
        //ㅇ도근형키: 9f30a1df-5a29-4e99-89a6-d1389a6108b4
        //승환키: ef2602ac-8a6e-442d-83d5-5fdc5d114b0f
        mMapView.setLanguage(TMapView.LANGUAGE_KOREAN);  // 지도 언어 설정
        mMapView.setMapType(TMapView.MAPTYPE_STANDARD);  // 지도 타입 표준
        mMapView.setIconVisibility(true);    // 현재위치 아이콘을 나타낼 것인지 표시
        mMapView.setZoomLevel(17);
        mMapView.MapZoomIn();
        mMapView.MapZoomOut();

        mMapView.setSightVisible(true); //지도 중앙에 출력

        mMapView.setCompassMode(true); //현재 보는 방향 (지도회전)
        mMapView.setSightVisible(true); //바라보는 방향 출력

        mContext = this;  // 타 액티비티에서 접근 가능하게 함.

        mOverlayview = new CameraOverlayview(this);
        mCameraActivity = new CameraActivity();
        coder = new Geocoder(getApplicationContext(), Locale.KOREA);


    final LocationListener locationListener = new LocationListener() {
        public void onLocationChanged(Location location) {

            latitude_plic = location.getLatitude();
            longitude_plic = location.getLongitude();

            if (point2 != null) {
                drawPedestrianPath();
            }

           // mOverlayview.setCurrentPoint(latitude_plic, longitude_plic, Ddistance);  // 현재위치 업데이트를 위해 mOverlayview에 값 전송
           // mCameraActivity.setCurrent(latitude_plic, longitude_plic);

            mMapView.setCenterPoint(longitude_plic, latitude_plic);
            mMapView.setLocationPoint(longitude_plic,latitude_plic);


            //mMapView.setSightVisible(true);
            //mMapView.setTrackingMode(true);
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
        }

        @Override
        public void onProviderEnabled(String provider) {
        }

        @Override
        public void onProviderDisabled(String provider) {
        }};

        final LocationManager lm = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_COARSE_LOCATION, android.Manifest.permission.ACCESS_FINE_LOCATION}, 1);
        }
        lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, // 등록할 위치제공자(실내에선 NETWORK_PROVIDER 권장)   GPS_PROVIDER
                2000, // 통지사이의 최소 시간간격 (miliSecond)
                1, // 통지사이의 최소 변경거리 (m)
                locationListener);

        // TTS를 생성하고 OnInitListener로 초기화 한다.
        tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if(status != ERROR) {
                    // 언어를 선택한다.
                    tts.setLanguage(Locale.KOREAN);
                }
            }
        });

        naviGuide();
        drawPedestrianPath();

        direction =(Button)findViewById(R.id.direction);
        direction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if((tLatitude+0.00008)>latitude_plic &&(tLatitude-0.00008)<latitude_plic
                        && (Longitude-0.0002)<longitude_plic && (Longitude+0.0002)>longitude_plic)
                {
                    check2=0;
                    tts.speak("목적지에 도착했습니다. 경로안내를 종료합니다.".toString(),TextToSpeech.QUEUE_FLUSH, null);

                    new Timer().schedule(new TimerTask() {
                        @Override
                        public void run() {
                            finish();
                        }
                    }, 4000);
                }

                if(check2==1) {
                    naviGuide();
                    drawPedestrianPath(); //도보 길안내를 선으로 그림
                }
            }
        });

        Button distancebutton=(Button)findViewById(R.id.distancebutton);
        distancebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int changedouble = Integer.parseInt(String.valueOf(Math.round(Ddistance)));

                String setdistance = Integer.toString(changedouble);
                tts.speak(setdistance+"미터 남았습니다.".toString(),TextToSpeech.QUEUE_FLUSH, null);

            }
        });

        //naviGuide();///////////////////////////////////////////////////////////////////////////////////////////////////////



    }


      public void onAccuracyChanged(Sensor sensor, int accuracy) {

      }

    public void onSensorChanged(SensorEvent event) {

            if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER)
                mGravity = event.values;
            if (event.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD)
                mGeomagnetic = event.values;
            if (mGravity != null && mGeomagnetic != null) {
                float R[] = new float[9];
                float I[] = new float[9];
                boolean success = SensorManager.getRotationMatrix(R, I, mGravity, mGeomagnetic);
            if (success) {
                float orientation[] = new float[3];
                SensorManager.getOrientation(R, orientation);
                mAzimut = (float)Math.toDegrees(orientation[0]);
                //mPitch = (float)Math.toDegrees(orientation[1]);
                //mRoll = (float)Math.toDegrees(orientation[2]);

                String result;
                result = "방위각:"+mAzimut;
                mResultView.setText(result);
            }
        }
    }


    public void drawPedestrianPath()   // 길찾기 함수
    {
        // final TMapPoint point1 = new TMapPoint(latitude_plic,longitude_plic);
        // point2 = new TMapPoint(des_latitude_plic,des_longitude_plic);

        final TMapPoint point1 = new TMapPoint(latitude_plic , longitude_plic);
        point2 = new TMapPoint(tLatitude, Longitude);

        TMapData tmapdata = new TMapData();
        tmapdata.findPathDataWithType(TMapData.TMapPathType.PEDESTRIAN_PATH, point1, point2, new TMapData.FindPathDataListenerCallback() {

            public void onFindPathData(TMapPolyLine polyLine) {
                polyLine.setLineColor(Color.BLUE);
                polyLine.setLineWidth(10);
                Ddistance = polyLine.getDistance();
                mMapView.addTMapPath(polyLine);

               /* if (Ddistance < 1000.0)
                {
                    String distance = longDouble2String(0,Ddistance);
                    Distance = distance + "m";
                    Log.d(TAG, "m = " + Distance);
                }
                else if(Ddistance >= 1000.0)
                {
                    float fDistance = (float) Ddistance / 1000;
                    String fdistance = longDouble2String(1,fDistance);
                    Distance = fdistance + "km";
                    Log.d(TAG, "km = " + Distance);
                }*/


            }
        });
    }
/*
texttest3.setText("Yes!?\n 방위" + mAzimut + "  \n deg" + Double.toString(degree) + "\n nodelan:" + nodelan + "\n nodelon: " + nodelon + "\n latitude_plic: " + latitude_plic + "\n longitude_plic: " + longitude_plic);
texttest2.setText("Yes");
runTTS("바라보는 방향입니다");
 */
    public void naviGuide() {
        TMapPoint point1 = new TMapPoint(latitude_plic , longitude_plic);
        TMapPoint point2 = new TMapPoint(tLatitude, Longitude);

        final TMapData tmapdata = new TMapData();
        mMapView.zoomToTMapPoint ( point1,point2 );  // 자동 zoomlevel 조정

        tmapdata.findPathDataAllType(TMapData.TMapPathType.PEDESTRIAN_PATH,point1, point2, new TMapData.FindPathDataAllListenerCallback(){
            @Override
            public void onFindPathDataAll(Document document) {
                document.getDocumentElement().normalize();
                Element root = document.getDocumentElement();

                for(int i=0; i<root.getElementsByTagName("Placemark").getLength(); i++) {
                    String a="";
                    Node placemark = root.getElementsByTagName("Placemark").item(i);
                    Node tmapindex = ((Element)placemark).getElementsByTagName("tmap:index").item(0);
                    String index=tmapindex.getTextContent();
                    Node nodeType = ((Element)placemark).getElementsByTagName("tmap:nodeType").item(0);
                    String nodetype=nodeType.getTextContent();
                    Node coordinate = ((Element)placemark).getElementsByTagName("coordinates").item(0);
                    String coordinates=coordinate.getTextContent();//좌표

                    if(nodeType.getTextContent().equals("POINT")) {
                        Node turnType = ((Element) placemark).getElementsByTagName("tmap:turnType").item(0);
                        a = Turntype(turnType.getTextContent());
                        nodeDatas.add(new NodeData(index,nodetype,coordinates,a));
                        }
                    else nodeDatas.add(new NodeData(index, nodetype, coordinates,a));
                }
                ArrayList<NodeData> node =(ArrayList<NodeData>)(Serializable)nodeDatas;
                String nextnode = node.get(2).coordinate.toString();
                String[] data = nextnode.split(",");
                if(isStringDouble(data[0])) {
                    double nodelon = Double.parseDouble(data[0]);
                    double nodelan = Double.parseDouble(data[1]);
                    //longitude경도 x축   latitude_plic위도 y축
                    double rad = Math.atan2(nodelon-longitude_plic,nodelan-latitude_plic);
                    double degree = (rad * 180) / Math.PI;

                    if ((degree+25)>180){
                        if(((degree-45)<mAzimut && 180>mAzimut) || ((degree+45-360)>mAzimut && (-180)<mAzimut) )
                             tts.speak("바라보는방향입니다.".toString(),TextToSpeech.QUEUE_FLUSH, null);
                        else
                            tts.speak("방향이틀립니다.".toString(),TextToSpeech.QUEUE_FLUSH, null);
                    }
                    else {
                        if ((degree - 45) < mAzimut && (degree + 45) > mAzimut)
                            tts.speak("바라보는방향입니다.".toString(),TextToSpeech.QUEUE_FLUSH, null);
                        else
                         tts.speak("방향이틀립니다.".toString(),TextToSpeech.QUEUE_FLUSH, null);
                    }
                    if((nodelan+0.00008)>latitude_plic &&(nodelan-0.00008)<latitude_plic
                            && (nodelon-0.0002)<longitude_plic && (nodelon+0.0002)>longitude_plic)//
                            tts.speak("잠시후 "+nodeDatas.get(2).turntype.toString()+"입니다.",TextToSpeech.QUEUE_ADD, null);
                }
                node.clear();
            }

        });

    }


    public String Turntype(String c)
    {
        switch (c)
        {
            case "11" : c="직진"; break;
            case "12" : c="좌회전"; break;
            case "13" : c="우회전"; break;
            case "14" : c="U-turn"; break;
            case "16" : c="8시 방향 좌회전"; break;
            case "17" : c="10방향 좌회전"; break;
            case "18" : c="2시 방향 우회전"; break;
            case "19" : c="4시 방향 우회전"; break;
            case "184" : c="첫번째 경유지"; break;
            case "186" : c="두번째 경유지"; break;
            case "187" : c="세번째 경유지"; break;
            case "188" : c="네번째 경유지"; break;
            case "189" : c="다섯번째 경유지"; break;
            case "125" : c="육교"; break;
            case "126" : c="지하보도"; break;
            case "127" : c="계단 진입"; break;
            case "128" : c="경사로 진입"; break;
            case "129" : c="계단 + 경사로 진입"; break;
            case "200" : c="출발지"; break;
            case "201" : c="목적지"; break;
            case "211" : c="횡단보도"; break;
            case "212" : c="좌측 횡단보도"; break;
            case "213" : c="우측 횡단보도"; break;
            case "214" : c="8시 방향 횡단보도"; break;
            case "215" : c="10시 방향 횡단보도"; break;
            case "216" : c="2시 방향 횡단보도"; break;
            case "217" : c="4시 방향 횡단보도"; break;
            case "218" : c="엘리베이터"; break;
        }

        return c;
    }

    private void showToast(String s) {
        Toast.makeText(getApplicationContext(), s, Toast.LENGTH_SHORT).show();
    }
    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        //mSensorManager.unregisterListener(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(tts !=null){
            tts.stop();
            tts.shutdown();
            tts = null;
        };

        mSensorManager.unregisterListener(this);
    }

    public static boolean isStringDouble(String s) { //숫자인지
        try {
            Double.parseDouble(s);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    public void onInit(int status){

    }

}

/*
        Search.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Toast.makeText(guide.this, "search", Toast.LENGTH_SHORT).show();
            findAllPoi();
        }
    });
*/

/*
        VR.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Toast.makeText(guide.this, "VR", Toast.LENGTH_SHORT).show();
            String end = my_destination.getText().toString();

            if (end == null || end.length() == 0) {
                showToast("검색어가 입력되지 않았습니다.");
                return;
            }
            //Toast.makeText(getApplicationContext(), "도착지 : " + end, Toast.LENGTH_SHORT).show();


            Intent intent = new Intent(guide.this, CameraActivity.class);
            intent.putExtra("latitude_id", String.valueOf(des_latitude_plic));  // CameraOverlayview 에 목적지값 전송 - cameraActivity 통해서 경유
            intent.putExtra("longitude_id", String.valueOf(des_longitude_plic));
            intent.putExtra("node", (Serializable) nodeDatas);
            startActivity(intent);


                List<Address> des_location = null;
                try {    //  도착위치 값 지오코딩.
                    des_location = coder.getFromLocationName(end, 5);
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    Toast.makeText(getApplicationContext(), "입출력오류 :" + e.getMessage() + "", Toast.LENGTH_SHORT).show();
                    e.printStackTrace();
                }
                des_latitude_plic = des_location.get(0).getLatitude();
                des_longitude_plic = des_location.get(0).getLongitude();
        }
    });
*/

/*
        roadservice.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
//            String query = my_destination.getText().toString();
            // if (query == null || query.length() == 0) {
            //   showToast("검색어가 입력되지 않았습니다.");
            //   return;
            //}

            drawPedestrianPath();
            naviGuide();
        }
    });
        */